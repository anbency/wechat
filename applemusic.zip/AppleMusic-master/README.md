# 可以播放音乐的微信小程序版 Apple Music
微信小程序，仿Apple Music  
搜索页只可以搜索，还不能播放
