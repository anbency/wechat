# 带用户登录的微信小程序 Demo

![](http://ww2.sinaimg.cn/large/40dfde6fjw1f8743ptc82g20av0iv78l.gif)

使用了 TeamToy 的 API  http://tt2net.vipsinaapp.com/#api

只实现了简单的 用户登录 、 TODO 列表 、 TODO 添加。目的是了解下小程序开发的流程和逻辑。

踩坑交流 QQ 群： 240520361
