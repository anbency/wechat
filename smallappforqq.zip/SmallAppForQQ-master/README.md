# SmallAppForQQ

   作者：Code4Android
   
   新浪微博：http://weibo.com/745687294
   
   CSDN  :    http://blog.csdn.net/xiehuimx?viewmode=contents
   
   简书   :   http://www.jianshu.com/users/d5b531888b2b/latest_articles
   

创建微信小程序(微信应用号)，后续开发仿QQ应用程序

实现微信小程序（微信应用号）QQ 

进度更新：

![](https://github.com/xiehui999/SmallAppForQQ/blob/master/images/qq.png)

2016/09/25 00:37  Add images,Realization funnction QQ tab.

2016/09/25 12:28  Create pages of message,contact,dynamic and  create dynamic title bar.

2016/09/25 18:05  Solve the "Page注册错误"errorerror.

2016/09/26 09:54  Add data in message.js file.

2016/09/26 13:09  Realization funnction of message pagepage.

2016/09/26 15:52  Perfect message page layout,add time,count field.

2016/09/26 16:08  Add App picture and adjust the picture to center display for message .

2016/09/26 22:46  Adjust layout

2016/09/27 12:09  Add a search box for a message page .

2016/09/27 18:33  Add part of the function of the contact page.


目前正在紧张的开发中...请稍后，持续更新



微信小程序资料推荐：

##[1. 小程序开发文档](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html)

##[2. 小程序设计指南](https://mp.weixin.qq.com/debug/wxadoc/design/index.html)

##[3. 小程序开发者工具](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html)
##[Windows 64](https://servicewechat.com/wxa-dev-logic/download_redirect?type=x64&amp;from=mpwiki&amp;t=1474887501301),[Windows 32](https://servicewechat.com/wxa-dev-logic/download_redirect?type=ia32&amp;from=mpwiki&amp;t=1474887501301),[MAC](https://servicewechat.com/wxa-dev-logic/download_redirect?type=darwin&amp;from=mpwiki&amp;t=1474887501301)


