# wechat-webapp-cnode
微信小应用学习 cnode版
[学习文档](./study.md)

![首页列表](http://7xqxfk.com1.z0.glb.clouddn.com//xiaoyingyong/cnode/1.png)
![内容详情](http://7xqxfk.com1.z0.glb.clouddn.com//xiaoyingyong/cnode/2.png)

